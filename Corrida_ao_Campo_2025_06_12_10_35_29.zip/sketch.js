function setup() {
  createCanvas(400, 400);
}

let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let jogador = ["🐷", "🍊", "🥔","🚜"];
let quantidade = jogador.length;

function draw() {
  ativarJogo();
  desenharJogadores();
  desenharLinhadeChegada();
  verificarGanhador();
}
function keyReleased() {
  if (key == "d") {
    xJogador[0] += random(25);
  }
  if (key == "p") {
    xJogador[1] += random(25);
  }
  if (key == "l") {
    xJogador[2] += random(25);
  }
    if (key == "h") {
    xJogador[3] += random(25);
  }
}
function ativarJogo() {
  if (focused) {
    background("rgb(26,121,26)");
  } else {
    background("#101B55");
  }
}
function desenharJogadores() {
  textSize(40);
  for (let i = 0; i < quantidade; i++) 
    text(jogador[i], xJogador[i], yJogador[i]);
}
function desenharLinhadeChegada() {
  fill("white");
  rect(350, 0, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}
function verificarGanhador() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350) {
      textSize(28)
      text(jogador[i] + "Chegamos no campo", 20, 200);
      noLoop();
    }
  }
}
